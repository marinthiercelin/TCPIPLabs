*****************
ryu.app.rest_vtep
*****************

.. automodule:: ryu.app.rest_vtep

REST API
========

.. autoclass:: ryu.app.rest_vtep.RestVtepController
   :members:
   :member-order: bysource
