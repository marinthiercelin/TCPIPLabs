# This module is for backward compat

from ryu.lib.packet.ether_types import *
